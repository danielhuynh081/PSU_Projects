#!/bin/bash

# R Jesse Chaney
# 

LAB=Lab5

VERBOSE=0
TOTAL_POINTS=0
TOTAL_AVAIL=0
MAKE_POINTS=0
WARN_POINTS=0
SUM_ONLY=0
CLEANUP=1
CLEAN_TARG=""

function buildPart {

    if [ ${VERBOSE} -eq 1 -a ${SUM_ONLY} -eq 0 ]
    then
	    echo "    Trying \"make $1\""
    fi

    rm -f $1
    make ${CLEAN_TARG} > /dev/null 2>&1
    make $1 > /dev/null 2>&1 
    if [ $? -eq 0 ]
    then
	    ((MAKE_POINTS+=5))
	    echo "      >> Passed \"make $1\"   ${MAKE_POINTS}"
    else
	    if [ ${VERBOSE} -eq 1 -a ${SUM_ONLY} -eq 0 ]
	    then
	        echo "      >> Failed \"make $1\""
	        echo "         Missing the $1 target in Makefile or too many errors during compilation."
	    fi
    fi
}

function build {
    BuildFailed=0

    if [ ${VERBOSE} -eq 1 ]
    then
	    echo ""
	    echo "Testing ${FUNCNAME} (the Makefile)"
    fi

    if [ ! -f Makefile -a ! -f makefile ]
    then
	    echo "      >>> There is no makefile or Makefile. This is bad. <<<"
	    echo "      >>>   Nothing can be built, all tests fail.        <<<"
	    echo "      >>>                                                <<<"
	    return
    fi
    ((MAKE_POINTS+=7))

    make clean > /dev/null
    if [ $? -eq 2 ]
    then
        echo "no target clean"
    
        make cls > /dev/null
        if [ $? -eq 2 ]
        then
            echo "no target cls"
        else
            CLEAN_TARG=cls
        fi
    else
        CLEAN_TARG=clean
    fi

    if [ $? -eq 0 ]
    then
        ((MAKE_POINTS+=5))
	    if [ ${VERBOSE} -eq 1 -a ${SUM_ONLY} -eq 0 ]
	    then
	        echo "    Passed \"make clean\""
	    fi
    else
	    if [ ${VERBOSE} -eq 1 -a ${SUM_ONLY} -eq 0 ]
	    then
	        echo "    >> Failed \"make clean/cls\""
	        echo "       Missing the clean/cls target in Makefile"
	    fi
    fi

    for TARG in all hex-2-float hex-2-float.o float-2-hex float-2-hex.o
    do
	    buildPart ${TARG}
    done

    make ${CLEAN_TARG} > /dev/null 2>&1
    if [ -e hex-2-float -o -e float-2-hex ]
    then
        echo "make ${CLEAN_TARG} does not remove executables: -1"
        ((MAKE_POINTS-=1))
    fi
    if [ -e hex-2-float.o -o -e float-2-hex.o ]
    then
        echo "make ${CLEAN_TARG} does not remove .o files: -1"
        ((MAKE_POINTS-=1))
    fi
    
    make ${CLEAN_TARG} > /dev/null 2>&1
    make 2> WARN.err > WARN.out

    NUM_BYTES=`wc -c < WARN.err`
    if [ ${NUM_BYTES} -eq 0 ]
    then
	    ((MAKE_POINTS+=2))
	    if [ ${VERBOSE} -eq 1 -a ${SUM_ONLY} -eq 0 ]
	    then
	        echo "      You had no warnings messages. Good job."
	    fi
    else
	    if [ ${VERBOSE} -eq 1 -a ${SUM_ONLY} -eq 0 ]
	    then
	        echo "      >> You had warnings messages. That is -20 percent!"
	    fi
    fi

    for FLAG in -Wall -Wshadow -Wunreachable-code \
	                  -Wredundant-decls -Wmissing-declarations \
	                  -Wold-style-definition -Wmissing-prototypes \
	                  -Wdeclaration-after-statement -Wextra -Werror -Wpedantic
    do
	    if [ ${VERBOSE} -eq 1 -a ${SUM_ONLY} -eq 0 ]
	    then
	        echo "    Looking for \"${FLAG}\" in build log"
	    fi

	    grep -c -- ${FLAG} WARN.out > /dev/null
	    if [ $? -eq 0 ]
	    then
	        ((MAKE_POINTS+=1))
	        if [ ${VERBOSE} -eq 1 -a ${SUM_ONLY} -eq 0 ]
	        then
		        echo "      Passed use of gcc flag ${FLAG}   ${MAKE_POINTS}"
	        fi
	    else
            echo "      ** Failed gcc flag ${FLAG} **"
	        if [ ${VERBOSE} -eq 1 -a ${SUM_ONLY} -eq 0 ]
	        then
		        echo "      >> Failed gcc flag ${FLAG}"
		        echo "         Missing from compiler flags; ${FLAG}"
	        fi
	    fi
    done

    echo "** Makefile points: ${MAKE_POINTS} of 50 **"

    ((TOTAL_POINTS+=${MAKE_POINTS}))

    if [ ${CLEANUP} -eq 1 ]
    then
	    rm -f ./WARN*
    fi
}

while getopts "xvC" opt
do
    case $opt in
	v)
	    # Print extra messages.
	    VERBOSE=1
	    ;;
	x)
	    # If you really, really, REALLY want to watch what is going on.
	    echo "Hang on for a wild ride."
	    set -x
	    ;;
	C)
	    # Skip removal of data files
	    CLEANUP=0
	    ;;
	\?)
	    echo "Invalid option" >&2
	    echo ""
	    #showHelp
	    exit 1
	    ;;
	:)
	    echo "Option -$OPTARG requires an argument." >&2
	    exit 1
	    ;;
    esac
done

build
make -s ${CLEAN_TARG}
