#include <stdio.h>

//gcc -Wall -g -o f2c f2c.c
//./f2c
//


int main(void)
{
	float fahrenheit =0.0;
	float celsius =0.0;

	printf("enter temperature in fahrenheit:");
	scanf("%f", &fahrenheit);

	celsius = (fahrenheit-32.0) * 5.0/9.0;
	printf("\ncelcius: %.4f\n", celsius);



	return 0;
}
