#include <stdio.h>

//gcc -Wall -o hello hello.c
//./hello
//

int main(void)
{
	printf("hello world\n");
	return 0;
}

